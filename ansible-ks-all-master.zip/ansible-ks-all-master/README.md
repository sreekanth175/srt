This is KS data all

# Playbook most important links 

### Tomcat Installation playbooks #####

http://myblogmchopker.blogspot.com/2017/08/ansible-tomcat-installation-deployment.html

https://github.com/ansible/ansible-examples/tree/master/tomcat-standalone
